package com.springlab.biz.board.impl;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.cglib.proxy.InvocationHandler;
import org.springframework.cglib.proxy.Proxy;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.springlab.biz.board.BoardService;
import com.springlab.biz.board.BoardVO;

public class BoardServiceClient {

	public static void main(String[] args) {

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(
					com.springlab.biz.common.AppContextConfig.class);
//		AbstractApplicationContext context = new ClassPathXmlApplicationContext(
//				"com/springlab/biz/common/AppContextConfig.xml");
		
//		BoardService boardService = (BoardService) context.getBean("boardService");

		BoardService boardServicObj = (BoardService) context.getBean("boardService");		
		BoardService boardService = (BoardService) Proxy.newProxyInstance(
				BoardServiceImpl.class.getClassLoader(), 
				new Class[] { BoardService.class }, 
				new InvocationHandler() {
					@Override
					public Object invoke(Object target, Method method, Object[] args) throws Throwable {
						long start = System.currentTimeMillis();
						
						Object result = method.invoke(boardServicObj, args);
						
						long end = System.currentTimeMillis();
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:MM:ss");
						System.out.printf("%s - %s : %d msec elapsed\n", 
								sdf.format(start), method.getName(), (end - start));		
						
						return result;
					}
				});
		
		BoardVO vo = new BoardVO();
		vo.setTitle("테스트 게시글");
		vo.setWriter("홍길동");
		vo.setContent("게시판 테스트 게시글입니다....");
		boardService.insertBoard(vo);
		
		vo.setSeq(1);
		vo = boardService.getBoard(vo);
		vo.setCnt(vo.getCnt()+1);
		boardService.updateBoard(vo);

		vo.setSeq(vo.getCnt());
		boardService.deleteBoard(vo);
		
		List<BoardVO> boardList = boardService.listBoard();
		for (BoardVO board : boardList) {
			System.out.printf("%d: %s\n", board.getSeq(), board.toString());
		}
			
		context.close();
	}

}
