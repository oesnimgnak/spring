package com.springlab.di_test;

public class SamsungTV2 implements TV {

	@Override
	public void powerOn() {
		System.out.println("SamsungTv - 전원을 켠다.");

	}

	@Override
	public void powerOff() {
		System.out.println("SamsungTv - 전원을 끈다.");

	}

	@Override
	public void volumeUp() {
		System.out.println("SamsungTv - 소리를 올린다.");

	}

	@Override
	public void volumeDown() {
		System.out.println("SamsungTv - 소리를 내린다.");

	}

}
