package com.springlab.di_test;

public class SamsungTV {
	public void powerOn() {
		System.out.println("SamsungTv - 전원을 켠다.");
	}
	
	public void powerOff() {
		System.out.println("SamsungTv - 전원을 끈다.");
	}
	
	public void volumeUp() {
		System.out.println("SamsungTv - 소리를 올린다.");
	}
	
	public void volumeDown() {
		System.out.println("SamsungTv - 소리를 내린다.");
	}
}
