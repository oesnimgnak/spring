package com.springlab.di_test;

public class LgTV {
	
	public void turnOn() {
		System.out.println("LgTV - 전원을 켠다.");
	}
	
	public void turnOff() {
		System.out.println("LgTV - 전원을 끈다.");
	}
	
	public void SoundUp() {
		System.out.println("LgTV - 소리를 올린다.");
	}
	
	public void SoundDown() {
		System.out.println("LgTV - 소리를 내린다.");
	}
}
