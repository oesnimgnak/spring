package com.springlab.di_test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TVUser {
	
//	private SamsungTV tv;
//	private LgTV tv;
	private TV tv;

	
	public TVUser() {
//		tv = new SamsungTV();
		tv = new LgTV2();
	}
	
	public TVUser(TV tv) {	
		this.tv = tv;
	}
	
	
	public void watchTV() {
		tv.powerOn();
		tv.powerOff();
		tv.volumeDown();
		tv.volumeUp();
//		tv.turnOff();
//		tv.turnOn();
//		tv.SoundDown();
//		tv.SoundUp();
	}

	public static void main(String[] args) {
//		TV tv = (new TVBeanFactory()).getBean(args[0]); 

		ApplicationContext context =
				new ClassPathXmlApplicationContext("classpath:appContextConfig.xml");
		TV tv = (TV) context.getBean("lg");	//오류 나는 이유 : 오브젝트라 캐스팅 해줘야함. 
		TVUser user = new TVUser(tv);	
		user.watchTV();

	}

}
