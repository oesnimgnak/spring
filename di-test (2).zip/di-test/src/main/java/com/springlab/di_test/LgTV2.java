package com.springlab.di_test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("lg")
public class LgTV2 implements TV {
	
	@Autowired //자동으로 실행. 3군데 1.생성자 기반 주입 2. setter메소드 앞 3.참조변수 앞에 바로 붙일 수있음
	@Qualifier("sony")
	private Speaker speaker;
	@Value("LG QLED-80")
	private String modelName;	//상수 값
	@Value("3500000")
	private int price;	//상수 값

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}

	@Override
	public void powerOn() {
		System.out.println("LgTV - 전원을 켠다.");

	}

	@Override
	public void powerOff() {
		System.out.println("LgTV - 전원을 끈다.");

	}

	@Override
	public void volumeUp() {
//		System.out.println("LgTV - 소리를 올린다.");
		speaker.volumUP();
	}

	@Override
	public void volumeDown() {
//		System.out.println("LgTV - 소리를 내린다.");
		speaker.volumDown();
	}

	@Override
	public String toString() {
		return "LgTV2 [speaker=" + speaker + ", modelName=" + modelName + ", price=" + price + "]";
	}

}
