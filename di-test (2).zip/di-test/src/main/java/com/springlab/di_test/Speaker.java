package com.springlab.di_test;

public interface Speaker {
	void volumUP();
	void volumDown();
}
